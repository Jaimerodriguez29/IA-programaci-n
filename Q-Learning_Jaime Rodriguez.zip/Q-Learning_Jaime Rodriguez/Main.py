import random

#  Parámetros 
alpha = 0.5        
gamma = 1.0       
episodios = 500
tope_pasos = 200
semilla = 42

random.seed(semilla)

# Mundo 
filas = 4
columnas = 12
inicio = (3, 0)
meta = (3, 11)

# Orden  de acciones 
acciones = ["N", "E", "S", "W"]


def es_acantilado(estado):
    fila = estado[0]
    col = estado[1]
    return fila == 3 and 1 <= col <= 10


def dar_paso(estado, accion):
 
    fila = estado[0]
    col = estado[1]

    # Calcular la casilla a la que iría
    if accion == "N":
        fila = fila - 1
    elif accion == "S":
        fila = fila + 1
    elif accion == "E":
        col = col + 1
    elif accion == "W":
        col = col - 1

    # Si se sale del mapa, se queda donde estaba
    if fila < 0 or fila >= filas or col < 0 or col >= columnas:
        fila = estado[0]
        col = estado[1]

    nuevo = (fila, col)

    if es_acantilado(nuevo):
        return inicio, -100, False   # cae: vuelve a S y el episodio sigue
    if nuevo == meta:
        return nuevo, -1, True       
    return nuevo, -1, False          


# Tabla Q 
# valor. Todo empieza en 0.
Q = {}
for f in range(filas):
    for c in range(columnas):
        for a in acciones:
            Q[((f, c), a)] = 0.0


def mejor_accion(estado):
    """Acción con mayor Q. En empate, la primera de la lista."""
    mejor = acciones[0]
    for a in acciones:
        if Q[(estado, a)] > Q[(estado, mejor)]:
            mejor = a
    return mejor


def max_q(estado):
    """Valor máximo de Q en un estado."""
    mejor = mejor_accion(estado)
    return Q[(estado, mejor)]


def elegir_accion(estado):
    """epsilon-greedy: a veces al azar, si no la mejor."""
    if random.random() < epsilon:
        return random.choice(acciones)
    return mejor_accion(estado)


# Entrenamiento 
recompensas = []   

for ep in range(episodios):
    estado = inicio
    total = 0

    for paso in range(tope_pasos):
        accion = elegir_accion(estado)
        nuevo, r, terminado = dar_paso(estado, accion)

        # Valor futuro: 0 si llegó a la meta
        if terminado:
            futuro = 0
        else:
            futuro = max_q(nuevo)

        
        objetivo = r + gamma * futuro
        Q[(estado, accion)] = Q[(estado, accion)] + alpha * (objetivo - Q[(estado, accion)])

        total = total + r
        estado = nuevo
        if terminado:
            break

    recompensas.append(total)


# Evaluación greedy 
estado = inicio
camino = [estado]
retorno = 0
for paso in range(tope_pasos):
    accion = mejor_accion(estado)
    estado, r, terminado = dar_paso(estado, accion)
    camino.append(estado)
    retorno = retorno + r
    if terminado:
        break

# Resultados 
flechas = {"N": "^", "E": ">", "S": "v", "W": "<"}

print("Semilla:", semilla)
print("Política greedy:")
for f in range(filas):
    linea = ""
    for c in range(columnas):
        if (f, c) == meta:
            linea = linea + " G"
        elif es_acantilado((f, c)):
            linea = linea + " C"
        else:
            linea = linea + " " + flechas[mejor_accion((f, c))]
    print(linea)

print("Camino:", camino)
print("Pasos:", len(camino) - 1)
print("Retorno greedy:", retorno)

# Media móvil de 10 episodios
print("\nEpisodio, recompensa, media móvil ")
for i in range(0, episodios, 50):
    inicio_ventana = max(0, i - 9)
    ventana = recompensas[inicio_ventana:i + 1]
    media = sum(ventana) / len(ventana)
    print(i + 1, recompensas[i], round(media, 1))

# Guardar todas las recompensas en un archivo
archivo = open("recompensas_basico.csv", "w")
archivo.write("episodio,recompensa\n")
for i in range(episodios):
    archivo.write(str(i + 1) + "," + str(recompensas[i]) + "\n")
archivo.close()
print("\nGuardado recompensas_basico.csv")