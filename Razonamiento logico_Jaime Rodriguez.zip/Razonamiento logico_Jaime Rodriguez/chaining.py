
import yaml


def parse_atom(texto):
    # "Estudiante(Ana)" -> ("Estudiante", ("Ana",))
    nombre, resto = texto.strip().split("(")
    args = resto.rstrip(")").split(",")
    args = tuple(a.strip() for a in args)
    return (nombre, args)

def fmt(atomo):
    return atomo[0] + "(" + ", ".join(atomo[1]) + ")"

def es_var(t):
    return t[0].islower()

# ---------- Sustituciones y unificación ---------

def valor(t, theta):
    # sigue la cadena de variables hasta una constante (o variable libre)
    while es_var(t) and t in theta:
        t = theta[t]
    return t

def subst(atomo, theta):
    nuevos = []
    for t in atomo[1]:
        nuevos.append(valor(t, theta))
    return (atomo[0], tuple(nuevos))

def unify(a, b, theta):
    """Devuelve una sustitución nueva si a y b unifican; si no, None."""
    if a[0] != b[0] or len(a[1]) != len(b[1]):
        return None
    theta = dict(theta)                       # copia, no modifica la original
    for i in range(len(a[1])):
        x = valor(a[1][i], theta)
        y = valor(b[1][i], theta)
        if x == y:
            continue
        elif es_var(x):
            theta[x] = y
        elif es_var(y):
            theta[y] = x
        else:                                 # dos constantes distintas
            return None
    return theta

# ---------- Carga ----------

def cargar_kb(ruta, hechos_extra=()):
    with open(ruta, encoding="utf-8") as f:
        datos = yaml.safe_load(f)
    hechos = []
    for h in datos["facts"] + list(hechos_extra):
        hechos.append(parse_atom(h))
    reglas = []
    for r in datos["rules"]:
        cuerpo = [parse_atom(p) for p in r["if"]]
        reglas.append({"id": r["id"], "cuerpo": cuerpo, "cabeza": parse_atom(r["then"])})
    consultas = [parse_atom(q) for q in datos["queries"]]
    return hechos, reglas, consultas

contador = 0

def renombrar(regla):
    """Cambia x por x_1, x_2... para que dos usos de una regla no compartan variable."""
    global contador
    contador += 1
    def ren(atomo):
        args = []
        for t in atomo[1]:
            args.append(t + "_" + str(contador) if es_var(t) else t)
        return (atomo[0], tuple(args))
    cuerpo = [ren(p) for p in regla["cuerpo"]]
    return cuerpo, ren(regla["cabeza"])

#  Encadenamiento hacia adelante 

def forward_chain(hechos, reglas, consulta):
    hechos = list(hechos)
    conocidos = list(hechos)
    nuevos = []
    traza = []
    ronda = 0
    while True:
        ronda += 1
        foto = list(hechos)                   
        nuevos_ronda = []
        for regla in reglas:
            cuerpo, cabeza = renombrar(regla)
            # unifica las premisas en orden, probando los hechos en orden
            thetas = [{}]
            for premisa in cuerpo:
                siguientes = []
                for th in thetas:
                    for hecho in foto:
                        th2 = unify(subst(premisa, th), hecho, th)
                        if th2 is not None:
                            siguientes.append(th2)
                thetas = siguientes
            for th in thetas:
                atomo = subst(cabeza, th)
                if atomo not in conocidos:    # no repetir átomos
                    conocidos.append(atomo)
                    nuevos_ronda.append(atomo)
                    sol = {}
                    for var, val in th.items():
                        sol[var.split("_")[0]] = val
                    traza.append(f"ronda {ronda}: {regla['id']} {sol} => {fmt(atomo)}")
        if len(nuevos_ronda) == 0:
            traza.append(f"ronda {ronda}: nada nuevo, punto fijo")
            break
        hechos = hechos + nuevos_ronda        # solo ahora sirven de premisa
        nuevos = nuevos + nuevos_ronda
    probada = False
    for hecho in hechos:
        if unify(consulta, hecho, {}) is not None:
            probada = True
            break
    return probada, nuevos, traza

#  Encadenamiento hacia atrás 


def backward_chain(hechos, reglas, consulta):
    traza = []

    def probar(metas, theta):
        """metas: lista de (átomo, pila, profundidad). Devuelve theta si prueba todas, si no None.
        pila = metas ancestro de esa meta (sirve para cortar ciclos)."""
        if len(metas) == 0:
            return theta
        atomo, pila, prof = metas[0]
        resto = metas[1:]
        g = subst(atomo, theta)
        traza.append("  " * prof + "meta " + fmt(g))

        if g in pila:                         # ciclo: se corta este camino
            traza.append("  " * prof + "ciclo: ya está en la pila, se corta")
            return None
        nueva_pila = pila + [g]

        # 1) primero los hechos
        for hecho in hechos:
            th = unify(g, hecho, theta)
            if th is not None:
                traza.append("  " * prof + "hecho " + fmt(hecho) + " ✓")
                resultado = probar(resto, th)
                if resultado is not None:     # primera prueba: se acepta
                    return resultado

        # 2) después las reglas, en el orden de la tabla
        for regla in reglas:
            cuerpo, cabeza = renombrar(regla)
            th = unify(cabeza, g, theta)
            if th is not None:
                traza.append("  " * prof + "regla " + regla["id"])
                premisas = []
                for p in cuerpo:
                    premisas.append((p, nueva_pila, prof + 1))
                resultado = probar(premisas + resto, th)
                if resultado is not None:
                    return resultado

        traza.append("  " * prof + "✗ falla " + fmt(g))
        return None

    resultado = probar([(consulta, [], 0)], {})
    return resultado is not None, traza


def correr(ruta, extra=(), titulo=""):
    hechos, reglas, consultas = cargar_kb(ruta, extra)
    print("\n" + "#" * 70 + "\n# " + titulo + "\n" + "#" * 70)
    for q in consultas:
        print("\n" + "=" * 70 + "\nConsulta: " + fmt(q) + "?\n" + "=" * 70)

        ok, nuevos, traza = forward_chain(hechos, reglas, q)
        print("\n--- Hacia adelante:", "SÍ (probada)" if ok else "NO")
        print("Átomos nuevos:", ", ".join(fmt(a) for a in nuevos))
        for linea in traza:
            print("  " + linea)

        ok, traza = backward_chain(hechos, reglas, q)
        print("\n--- Hacia atrás:", "SÍ (probada)" if ok else "NO")
        for linea in traza:
            print("  " + linea)

if __name__ == "__main__":
    ruta = "kb/biblioteca.yaml"
    correr(ruta, titulo="BASE ORIGINAL")
    correr(ruta, extra=["TieneCredencial(Luis)"],
           titulo="CON HECHO EXTRA: TieneCredencial(Luis)")
